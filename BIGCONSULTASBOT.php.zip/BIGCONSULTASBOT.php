<?php 
define('BOT_TOKEN', '1632148011:AAE09Ibjh6h8fuF8Th-2ITjgXz9sYNbG3L8'); 
define('API_URL', 'https://api.telegram.org/bot'.BOT_TOKEN.'/');

function apiRequestWebhook($method, $parameters) {
	if (!is_string($method)) {
		error_log("Nome do método deve ser uma string\n"); 
		return false; 
	} 
	if (!$parameters) {
		$parameters = array(); 
	} else if (!is_array($parameters)) {
		error_log("Os parâmetros devem ser um array\n"); 
		return false; 
	} 
	$parameters["method"] = $method; 
	header("Content-Type: application/json"); 
	echo json_encode($parameters); 
	return true; 
} 
function exec_curl_request($handle) {
	$response = curl_exec($handle); 
	if ($response === false) {
		$errno = curl_errno($handle); 
		$error = curl_error($handle); 
		error_log("Curl retornou um erro $errno: $error\n"); 
		curl_close($handle); 
		return false; 
	} 
	$http_code = intval(curl_getinfo($handle, CURLINFO_HTTP_CODE)); 
	curl_close($handle); 
	if ($http_code >= 500) {
		// do not wat to DDOS server if something goes wrong 
		sleep(10); 
		return false; 
	} else if ($http_code != 200) {
		$response = json_decode($response, true); 
		error_log("Request has failed with error {$response['error_code']}: {$response['description']}\n"); 
		if ($http_code == 401) {
			throw new Exception('Invalid access token provided'); 
		} 
		return false; 
	} else {
		$response = json_decode($response, true); 
		if (isset($response['description'])) {
			error_log("Request was successfull: {$response['description']}\n"); 
		} 
		$response = $response['result']; 
	} 
	return $response; 
} 
function apiRequest($method, $parameters) {
	if (!is_string($method)) {
		error_log("Method name must be a string\n"); 
		return false; 
	} 
	if (!$parameters) {
		$parameters = array(); 
	} else if (!is_array($parameters)) {
		error_log("Parameters must be an array\n"); 
		return false; 
	} 
	foreach ($parameters as $key => &$val) {
		// encoding to JSON array parameters, for example reply_markup 
		if (!is_numeric($val) && !is_string($val)) {
			$val = json_encode($val); 
		} 
	} 
	$url = API_URL.$method.'?'.http_build_query($parameters); 
	$handle = curl_init($url); 
	curl_setopt($handle, CURLOPT_RETURNTRANSFER, true); 
	curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 5); 
	curl_setopt($handle, CURLOPT_TIMEOUT, 60); 
	return exec_curl_request($handle); 
} 
function apiRequestJson($method, $parameters) {
	if (!is_string($method)) {
		error_log("Method name must be a string\n"); 
		return false; 
	} 
	if (!$parameters) {
		$parameters = array(); 
	} else if (!is_array($parameters)) {
		error_log("Parameters must be an array\n"); 
		return false; 
	} 
	$parameters["method"] = $method; 
	$handle = curl_init(API_URL); 
	curl_setopt($handle, CURLOPT_RETURNTRANSFER, true); 
	curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 5); 
	curl_setopt($handle, CURLOPT_TIMEOUT, 60); 
	curl_setopt($handle, CURLOPT_POSTFIELDS, json_encode($parameters)); 
	curl_setopt($handle, CURLOPT_HTTPHEADER, array("Content-Type: application/json")); 
	return exec_curl_request($handle); 
} 
function processaCallbackQuery($callback){
  $BOT_TOKEN = "1632148011:AAE09Ibjh6h8fuF8Th-2ITjgXz9sYNbG3L8";
  $callback_id = $callback['id'];
  $chat_id = $callback['message']['chat']['id'];
  $type = $callback['message']['chat']['type'];
  $message_id = $callback['message']['message_id'];
  $user_id = $callback['from']['id'];
  $user_name = $callback['from']['username']; 
  $name = $callback['from']['first_name'];
  $data =  $callback['data'];
  $data_array=unserialize($data);
  $anterior = $message_id - 1;
  $adm = "1484706029";
  $adm2 = "902983459";
  
  if($data_array['data']=="apagar") {
     if($data_array['id']==$callback['from']['id']) {      
         apiRequest("deleteMessage", array('chat_id' => $chat_id, 'message_id' => $message_id));
         apiRequest("deleteMessage", array('chat_id' => $chat_id, 'message_id' => $anterior));
         
     } else {
  
         apiRequest("answerCallbackQuery", array('callback_query_id' => $callback_id, 'text' => "Você não tem permissão!"));
      
     }
  } else if ($data == "apagar") {    
    apiRequest("deleteMessage", array('chat_id' => $chat_id, 'message_id' => $message_id));
    apiRequest("deleteMessage", array('chat_id' => $chat_id, 'message_id' => $anterior));
  
  } else if ($data == 'menu') {
         
      apiRequest("editMessageText", array('chat_id' => $chat_id, 'message_id' => $message_id, "parse_mode" => "Markdown", "text" => '*⚙️ 𝗠𝗘𝗡𝗨 𝗗𝗘 𝗖𝗢𝗠𝗔𝗡𝗗𝗢𝗦 ⚙️*',
      'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                              
                                                     //linha 1
                                                     array(                                                                                                               
                                                         array('text'=>'🌐 CONSULTAS VIP 🌐',"callback_data"=>'consultas')
                                                      ),
                                                     //linha 2
                                                     array(
                                                         array('text'=>'🎵 Baixar músicas do YouTube 🎵',"callback_data"=>'youtube')                        
                                                     )
                                                                                                                                                                                 
                                            )
                                    )));
   
   }else if($data_array['data']=="adm") {
       if($data_array['id']==$callback['from']['id']) {  

           $getAdmins = apiRequest('getChatAdministrators', array('chat_id' => $chat_id));
           $json = json_encode($getAdmins, true);
 
           $listAdmins = explode('username":"', $json);
           for ($i=1; $i < count($listAdmins); $i++) { 
               $admins = explode('"', $listAdmins[$i]);
               $adms = $adms." ".$admins[0];
           }
                
          if(!stripos($adms, "BIGCONSULTASBOT")) {         
              apiRequest("answerCallbackQuery", array('callback_query_id' => $callback_id, 'show_alert' => true, 'text' => "OPS‼️...

Parece que eu ainda não sou administrador do grupo...
Para continuar me coloque como administrador. 😉"));             
          }else{              
              apiRequest("editMessageText", array('chat_id' => $chat_id, 'message_id' => $message_id, "parse_mode" => "Markdown", "text" => "✅ Excelente! :)

Agora clique no botão do Menu para conhecer todos os meus comandos!",
'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🔘  Menu  🔘',"callback_data"=>'menu'), //botão 1                                                 
                                                      )
                                                          
                                            )
                                    )));
          }
       } else {
  
           apiRequest("answerCallbackQuery", array('callback_query_id' => $callback_id, 'text' => "Você não tem permissão!"));

       }

   } else if ($data == 'queroservip') {

       include("botcon/planos.php");
       
   } else if ($data == 'creditos') {

       include("botcon/creditos.php");
       
   } else if ($data == 'youtube') {           
           apiRequest("editMessageText", array('chat_id' => $chat_id, 'message_id' => $message_id, "parse_mode" => "Markdown", "text" => '*🎵 Baixar músicas do YouTube*

_Para baixar alguma música do Youtube. Você precisa digitar o comando seguido do link do video do Youtube.

Exemplo:_

`#musica https://youtu.be/8TARxeWR_6Y`',
'reply_markup' => array('inline_keyboard' => array(                                                                                                        
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🔙  Voltar  🔙',"callback_data"=>'menu'), //botão 1
                                                      )
                                                          
                                            )
                                    )));
       
   } else if ($data == 'vipprivado') {
    apiRequest("editMessageText", array('chat_id' => $chat_id, 'message_id' => $message_id, "parse_mode" => "Markdown", "text" => '
*═════════════════════
𝗖𝗔𝗗𝗦𝗨𝗦 
𝗖𝗥𝗘𝗗𝗜𝗟𝗜𝗡𝗞 
𝗗𝗘𝗧𝗥𝗔𝗡 
𝗧𝗔𝗥𝗚𝗘𝗧 
𝗩𝗜𝗔 𝗖𝗔𝗥 
𝗦𝗛𝗜𝗙𝗧𝗗𝗔𝗧𝗔 
═════════════════════

 𝗧𝗔𝗕𝗘𝗟𝗔 𝗗𝗘 𝗣𝗥𝗘𝗖̧𝗢𝗦 𝗣𝗟𝗔𝗡𝗢 𝗜𝗡𝗗𝗜𝗩𝗜𝗗𝗨𝗔𝗟 

[✅]  07 𝙳𝙸𝙰𝚂 25 𝚁$
[✅]  15 𝙳𝙸𝙰𝚂 35 𝚁$
[✅]  30 𝙳𝙸𝙰𝚂 50 𝚁$ 
[✅]  60 𝙳𝙸𝙰𝚂 85 𝚁$


 𝙏𝘼𝘽𝙀𝙇𝘼 𝘿𝙀 𝙋𝙍𝙀𝘾̧𝙊𝙎 𝙋𝘼𝙍𝘼 𝙂𝙍𝙐𝙋𝙊 𝙑𝙄𝙋 

[✅] 7 𝙳𝙸𝙰𝚂 45 𝚁$ 
[✅] 15 𝙳𝙸𝙰𝚂 65 𝚁$ 
[✅] 1 𝙼𝙴𝚂 90 𝚁$

💰 𝙁𝙊𝙍𝙈𝘼𝙎 𝘿𝙀 𝙋𝘼𝙂𝘼𝙈𝙀𝙉𝙏𝙊 💰

----------------------------------------------
💰𝗠𝗘𝗥𝗖𝗔𝗗𝗢 𝗣𝗔𝗚𝗢 
💰𝗧𝗘𝗗 
💰𝗣𝗜𝗫 
💰𝗕𝗢𝗟𝗘𝗧𝗢 
💰𝗟𝗢𝗧𝗘́𝗥𝗜𝗖𝗔
----------------------------------------------*',
'reply_markup' => array('inline_keyboard' => array(                                                                                                        
                                                     //linha 1
                                                     array(
                                                         array('text'=>'CONTATO DO VENDEDOR','url'=>'https://t.me/StarkTheBest')
                                                      )
                                                          
                                            )
                                    )));

  } else if ($data == 'vipgrupo') {
    apiRequest("editMessageText", array('chat_id' => $chat_id, 'message_id' => $message_id, "parse_mode" => "Markdown", "text" => '
*═════════════════════
𝗖𝗔𝗗𝗦𝗨𝗦 
𝗖𝗥𝗘𝗗𝗜𝗟𝗜𝗡𝗞 
𝗗𝗘𝗧𝗥𝗔𝗡 
𝗧𝗔𝗥𝗚𝗘𝗧 
𝗩𝗜𝗔 𝗖𝗔𝗥 
𝗦𝗛𝗜𝗙𝗧𝗗𝗔𝗧𝗔 
═════════════════════

 𝗧𝗔𝗕𝗘𝗟𝗔 𝗗𝗘 𝗣𝗥𝗘𝗖̧𝗢𝗦 𝗣𝗟𝗔𝗡𝗢 𝗜𝗡𝗗𝗜𝗩𝗜𝗗𝗨𝗔𝗟 

[✅]  07 𝙳𝙸𝙰𝚂 25 𝚁$
[✅]  15 𝙳𝙸𝙰𝚂 35 𝚁$
[✅]  30 𝙳𝙸𝙰𝚂 50 𝚁$ 
[✅]  60 𝙳𝙸𝙰𝚂 85 𝚁$


 𝙏𝘼𝘽𝙀𝙇𝘼 𝘿𝙀 𝙋𝙍𝙀𝘾̧𝙊𝙎 𝙋𝘼𝙍𝘼 𝙂𝙍𝙐𝙋𝙊 𝙑𝙄𝙋 

[✅] 7 𝙳𝙸𝙰𝚂 45 𝚁$ 
[✅] 15 𝙳𝙸𝙰𝚂 65 𝚁$ 
[✅] 1 𝙼𝙴𝚂 90 𝚁$

💰 𝙁𝙊𝙍𝙈𝘼𝙎 𝘿𝙀 𝙋𝘼𝙂𝘼𝙈𝙀𝙉𝙏𝙊 💰

----------------------------------------------
💰𝗠𝗘𝗥𝗖𝗔𝗗𝗢 𝗣𝗔𝗚𝗢 
💰𝗧𝗘𝗗 
💰𝗣𝗜𝗫 
💰𝗕𝗢𝗟𝗘𝗧𝗢 
💰𝗟𝗢𝗧𝗘́𝗥𝗜𝗖𝗔
----------------------------------------------*',
'reply_markup' => array('inline_keyboard' => array(                                                                                                        
                                                     //linha 1
                                                     array(
                                                         array('text'=>'CONTATO DO VENDEDOR','url'=>'https://t.me/StarkTheBest')
                                                      )                                                     
                                                          
                                            )
                                    )));
                                                                         
    } else if ($data == 'consultas') {
    apiRequest("editMessageText", array('chat_id' => $chat_id, 'message_id' => $message_id, "parse_mode" => "Markdown", "text" => '🔍 *CONSULTAS VIP*
═════════════════════
*CADSUS*

|> NOME: `#nome LUCIANO SILVA`

|> CNS: `#cns 700802423158685`
═════════════════════
*CREDILINK*

|> TELEFONE: `#tel 51995379721`
═════════════════════
*TARGET*

|> CPF ( 1 ) `#cpf1 34592913892`

|> CNPJ: `#cnpj 27865757000102`
═════════════════════
*SHIFTDATA*

|> CPF ( 2 ) `#cpf2 34592913892`
═════════════════════
*DETRAN*

|> PLACA ( 1 ) `#placa1 JJK1960`
|> PLACA ( 2 ) `#placa2 JJK1960`
═════════════════════
*SERASA*

|> SCORE: `#score 27867260854`
═════════════════════',
'reply_markup' => array('inline_keyboard' => array(                                                                                                        
                                                      //linha 1
                                                     array(
                                                         array('text'=>'⏺ CONTRATAR PLANOS ⏺','url'=>'http://t.me/StarkTheBest')                                           
                                                      ),                 
                                                      //linha 2
                                                     array(
                                                         array('text'=>'🔙  Voltar  🔙',"callback_data"=>'menu')                                
                                                      )
                                                          
                                            )
                                    )));

  }
  apiRequest("answerCallbackQuery", array('callback_query_id' => $callback_id));
}


function processMessage($message) {
	// process incoming message 
	$BOT_TOKEN = "1632148011:AAE09Ibjh6h8fuF8Th-2ITjgXz9sYNbG3L8";
    $message_id = $message['message_id'];   
    $chat_id = $message['chat']['id'];
    $type = $message['chat']['type'];
    $titulo = $message['chat']['title'];
    $user_id = $message['from']['id'];
    $first_name = $message['from']['first_name'];
	$last_name = $message['from']['last_name'];
    $username = $message['from']['username'];
    $is_bot = $message['new_chat_participant']['is_bot'];
    $member_name = $message['new_chat_participant']['first_name'];
	$member_last_name = $message['new_chat_participant']['last_name'];
    $member_user = $message['new_chat_participant']['username'];
    $reply_to_message_user_id = $message['reply_to_message']['from']['id'];
    $reply_to_message_name = $message['reply_to_message']['from']['first_name'];
    $reply_to_message_last_name = $message['reply_to_message']['from']['last_name'];
    $reply_to_message_user = $message['reply_to_message']['from']['username'];
    $reply_to_message_id = $message['reply_to_message']['message_id'];
    $forward_from_id = $message['reply_to_message']['forward_from']['id'];
    $forward_from_name = $message['reply_to_message']['forward_from']['first_name'];
    $forward_from_last_name = $message['reply_to_message']['forward_from']['last_name'];
    $forward_from_user = $message['reply_to_message']['forward_from']['username'];       
    $adm = "1484706029";
    $adm2 = "902983459";

    date_default_timezone_set('America/Recife');
    $diasemana = array('Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sabado');
    $data = date('Y/m/d');
    $diasemana_numero = date('w', strtotime($data));
    $dataCerta = date('d/m/Y');
    $hora = date('H:i:s');
    $minuto = date('i');
    $segundo = date('s');

    if (isset($member_name)) {
		if ($member_user !== 'BIGCONSULTASBOT') {
			
			
         } else if($member_user == 'BIGCONSULTASBOT') {
		
           $getAdmins = apiRequest('getChatAdministrators', array('chat_id' => $chat_id));
           $json = json_encode($getAdmins, true);
 
            $listAdmins = explode('username":"', $json);
            for ($i=1; $i < count($listAdmins); $i++) { 
                $admins = explode('"', $listAdmins[$i]);
                $adms = $adms." ".$admins[0];
            }
                                         
            if(stripos($adms, "BIGCONSULTASBOT")) { 
                                                   
                apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => '*Obrigado por me adicionar como um Administrador no seu grupo!

Conheça a baixo, todos os meus comandos:*', "reply_to_message_id" => $message_id,
		       'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                             
                                                     //linha 1
                                                     array(                                                                                                               
                                                         array('text'=>'🌐 CONSULTAS VIP 🌐',"callback_data"=>'consultas')
                                                      ),
                                                     //linha 2
                                                     array(
                                                         array('text'=>'🎵 Baixar músicas do YouTube 🎵',"callback_data"=>'youtube')                        
                                                     )
                                            )
                                    )));
                                       
            }else{
                
                date_default_timezone_set('America/Recife');
                $dt_atual = date("Y/m/d H:i:s");
                $timestamp_dt_atual = strtotime($dt_atual);
			
			    $array_grupos = file("botcon/grupos.txt");
                $total_grupos_registrados = count($array_grupos);

                $continuarGrupo = false;
                for($i=0;$i<count($array_grupos);$i++){
                    $grupo_vip = explode("|" , $array_grupos[$i]);
                    if($chat_id == "-$grupo_vip[0]"){
                        $vencimento2 = $grupo_vip[1];
                        $continuarGrupo = true;
                    }
                }
            
                $timestamp_dt_expira2 = strtotime($vencimento2);
                   
                if(!$continuarGrupo || $timestamp_dt_atual > $timestamp_dt_expira2){                                                                                                                   
                    apiRequest('leaveChat', array('chat_id' => $chat_id));                                                                                         
                }
                                                               
                apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => '*✅ OK! Você me adicionou no grupo!

Só tem mais uma coisa...
Para utilizar todas as minhas ferramentas você precisa me colocar como administrador 😉*',
		    'reply_markup' => array('inline_keyboard' => array(                                                      
                                                      //linha 1
                                                     array(                                               
                                                         array('text'=>'Ok, já te coloquei como ADM',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'adm']))                            
                                                      )
                                            )
                                    )));
                
            }
        }
    }
	

    if (isset($message['text'])) {
        $text = $message['text']; 
		$member_name = $message['from']['first_name'];
	

$verifica = substr(strtoupper($text), 0,5) == '#CPF1';
  
if($verifica && $type == 'private') {
                
    date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);

    $array_usuarios = file("botcon/usuarios.txt");
    $total_usuarios_registrados = count($array_usuarios);

    $continuar = false;
    for($i=0;$i<count($array_usuarios);$i++){
        $explode = explode("|" , $array_usuarios[$i]);
        if($user_id == $explode[0]){
            $vencimento = $explode[1];
            $continuar = true;
        }
    }

    $timestamp_dt_expira = strtotime($vencimento);
				
    if(!$continuar || $timestamp_dt_atual > $timestamp_dt_expira){
         $verifica = "";
    }

}else if($verifica && $type != 'private') {
	
	date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);
			
    $array_grupos = file("botcon/grupos.txt");
    $total_grupos_registrados = count($array_grupos);

    $continuarGrupo = false;
    for($i=0;$i<count($array_grupos);$i++){
        $grupo_vip = explode("|" , $array_grupos[$i]);
        if($chat_id == "-$grupo_vip[0]"){
            $vencimento2 = $grupo_vip[1];
            $continuarGrupo = true;
         }
     }
            
     $timestamp_dt_expira2 = strtotime($vencimento2);
                   
     if(!$continuarGrupo || $timestamp_dt_atual > $timestamp_dt_expira2){                                                                                                                   
         apiRequest('leaveChat', array('chat_id' => $chat_id));                                                                                         
     }
 
}
  
        if($verifica){
            $login = substr($text, 6);
            if($login){
               $split = explode(" ", $login);               
               $comando = $split[0];

               include("botcon/cpf.php");
                                                             
            }else{
                
                if($type == 'private') {
	
                    
                    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => '*CPF Checker* - _Consulta simples de CPF, obtém dados do portador.

Formato:_
27867260854
_ou_
278.672.608-54

`#cpf1 27867260854`',
   'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

               }else{
                   
                   
                   apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*CPF Checker* - _Consulta simples de CPF, obtém dados do portador.

Formato:_
27867260854
_ou_
278.672.608-54

`#cpf1 27867260854`", "reply_to_message_id" => $message_id,
'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

               }
            }
        }
        
        
$verifica = substr(strtoupper($text), 0,5) == '#CPF2';
   
if($verifica && $type == 'private') {
                
    date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);

    $array_usuarios = file("botcon/usuarios.txt");
    $total_usuarios_registrados = count($array_usuarios);

    $continuar = false;
    for($i=0;$i<count($array_usuarios);$i++){
        $explode = explode("|" , $array_usuarios[$i]);
        if($user_id == $explode[0]){
            $vencimento = $explode[1];
            $continuar = true;
        }
    }

    $timestamp_dt_expira = strtotime($vencimento);
				
    if(!$continuar || $timestamp_dt_atual > $timestamp_dt_expira){
         $verifica = "";
    }

}else if($verifica && $type != 'private') {
	
	date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);
			
    $array_grupos = file("botcon/grupos.txt");
    $total_grupos_registrados = count($array_grupos);

    $continuarGrupo = false;
    for($i=0;$i<count($array_grupos);$i++){
        $grupo_vip = explode("|" , $array_grupos[$i]);
        if($chat_id == "-$grupo_vip[0]"){
            $vencimento2 = $grupo_vip[1];
            $continuarGrupo = true;
         }
     }
            
     $timestamp_dt_expira2 = strtotime($vencimento2);
                   
     if(!$continuarGrupo || $timestamp_dt_atual > $timestamp_dt_expira2){                                                                                                                   
         apiRequest('leaveChat', array('chat_id' => $chat_id));                                                                                         
     }
 
}
 
        if($verifica){
            $login = substr($text, 6);
            if($login){
               $split = explode(" ", $login);               
               $comando = $split[0];

               include("botcon/cpf2.php");
                                                             
            }else{
                
                if($type == 'private') {
	
                    
                    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => '*CPF Checker* - _Consulta completa de CPF, obtém dados do portador.

Formato:_
27867260854
_ou_
278.672.608-54

`#cpf2 27867260854`',
   'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

               }else{
                   
                   
                   apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*CPF Checker* - _Consulta completa de CPF, obtém dados do portador.

Formato:_
27867260854
_ou_
278.672.608-54

`#cpf2 27867260854`", "reply_to_message_id" => $message_id,
'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

               }
            }
        }
        
                  
$verifica = substr(strtoupper($text), 0,6) == '#SCORE';
   
if($verifica && $type == 'private') {
                
    date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);

    $array_usuarios = file("botcon/usuarios.txt");
    $total_usuarios_registrados = count($array_usuarios);

    $continuar = false;
    for($i=0;$i<count($array_usuarios);$i++){
        $explode = explode("|" , $array_usuarios[$i]);
        if($user_id == $explode[0]){
            $vencimento = $explode[1];
            $continuar = true;
        }
    }

    $timestamp_dt_expira = strtotime($vencimento);
				
    if(!$continuar || $timestamp_dt_atual > $timestamp_dt_expira){
         $verifica = "";
    }

}else if($verifica && $type != 'private') {
	
	date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);
			
    $array_grupos = file("botcon/grupos.txt");
    $total_grupos_registrados = count($array_grupos);

    $continuarGrupo = false;
    for($i=0;$i<count($array_grupos);$i++){
        $grupo_vip = explode("|" , $array_grupos[$i]);
        if($chat_id == "-$grupo_vip[0]"){
            $vencimento2 = $grupo_vip[1];
            $continuarGrupo = true;
         }
     }
            
     $timestamp_dt_expira2 = strtotime($vencimento2);
                   
     if(!$continuarGrupo || $timestamp_dt_atual > $timestamp_dt_expira2){                                                                                                                   
         apiRequest('leaveChat', array('chat_id' => $chat_id));                                                                                         
     }
 
}
 
        if($verifica){
            $login = substr($text, 7);
            if($login){
               $split = explode(" ", $login);               
               $comando = $split[0];

               include("botcon/score.php");
                                                             
            }else{
                
                if($type == 'private') {
	
                    
                    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => '*SCORE Checker* - _Consulta completa de CPF com SCORE, obtém dados do portador.

Formato:_
27867260854
_ou_
278.672.608-54

`#score 27867260854`',
   'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

               }else{
                   
                   
                   apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*SCORE Checker* - _Consulta completa de CPF com SCORE, obtém dados do portador.

Formato:_
27867260854
_ou_
278.672.608-54

`#score 27867260854`", "reply_to_message_id" => $message_id,
'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

               }
            }
        }

       
$verifica = substr(strtoupper($text), 0,4) == '#CNS';
   
if($verifica && $type == 'private') {
                
    date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);

    $array_usuarios = file("botcon/usuarios.txt");
    $total_usuarios_registrados = count($array_usuarios);

    $continuar = false;
    for($i=0;$i<count($array_usuarios);$i++){
        $explode = explode("|" , $array_usuarios[$i]);
        if($user_id == $explode[0]){
            $vencimento = $explode[1];
            $continuar = true;
        }
    }

    $timestamp_dt_expira = strtotime($vencimento);
				
    if(!$continuar || $timestamp_dt_atual > $timestamp_dt_expira){
         $verifica = "";
    }

}else if($verifica && $type != 'private') {
	
	date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);
			
    $array_grupos = file("botcon/grupos.txt");
    $total_grupos_registrados = count($array_grupos);

    $continuarGrupo = false;
    for($i=0;$i<count($array_grupos);$i++){
        $grupo_vip = explode("|" , $array_grupos[$i]);
        if($chat_id == "-$grupo_vip[0]"){
            $vencimento2 = $grupo_vip[1];
            $continuarGrupo = true;
         }
     }
            
     $timestamp_dt_expira2 = strtotime($vencimento2);
                   
     if(!$continuarGrupo || $timestamp_dt_atual > $timestamp_dt_expira2){                                                                                                                   
         apiRequest('leaveChat', array('chat_id' => $chat_id));                                                                                         
     }
 
}
 
        if($verifica){
            $login = substr($text, 5);
            if($login){
               $split = explode(" ", $login);               
               $comando = $split[0];

               include("botcon/cns.php");
                                                             
            }else{
                
                if($type == 'private') {
	
                    
                    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => '*CNS Checker* - _Consulta completa de CNS, obtém dados do portador.

Formato:_
700802423158685

`#cns 700802423158685`',
   'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

               }else{
                   
                   
                   apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*CNS Checker* - _Consulta completa de CNS, obtém dados do portador.

Formato:_
700802423158685

`#cns 700802423158685`", "reply_to_message_id" => $message_id,
'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

               }
            }
        }
                         
                         
$verifica = substr(strtoupper($text), 0,5) == '#CNPJ';

if($verifica && $type == 'private') {
                
    date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);

    $array_usuarios = file("botcon/usuarios.txt");
    $total_usuarios_registrados = count($array_usuarios);

    $continuar = false;
    for($i=0;$i<count($array_usuarios);$i++){
        $explode = explode("|" , $array_usuarios[$i]);
        if($user_id == $explode[0]){
            $vencimento = $explode[1];
            $continuar = true;
        }
    }

    $timestamp_dt_expira = strtotime($vencimento);
				
    if(!$continuar || $timestamp_dt_atual > $timestamp_dt_expira){
         $verifica = "";
    }

}else if($verifica && $type != 'private') {
	
	date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);
			
    $array_grupos = file("botcon/grupos.txt");
    $total_grupos_registrados = count($array_grupos);

    $continuarGrupo = false;
    for($i=0;$i<count($array_grupos);$i++){
        $grupo_vip = explode("|" , $array_grupos[$i]);
        if($chat_id == "-$grupo_vip[0]"){
            $vencimento2 = $grupo_vip[1];
            $continuarGrupo = true;
         }
     }
            
     $timestamp_dt_expira2 = strtotime($vencimento2);
                   
     if(!$continuarGrupo || $timestamp_dt_atual > $timestamp_dt_expira2){                                                                                                                   
         apiRequest('leaveChat', array('chat_id' => $chat_id));                                                                                         
     }
 
}

        if($verifica){
            $login = substr($text, 6);
            if($login){
               $split = explode(" ", $login);
               $comando = $split[0];

               include("botcon/cnpj.php");

            }else{
                
                if($type == 'private') {
	
                    
                    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*CNPJ Checker* - _Consulta completa de CNPJ, obtém todos os dados da empresa e nome do(s) proprietário(s) e sócio(s).

Formato:_
27865757000102
_ou_
27.865.757/0001-02

`#cnpj 27865757000102`",
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

                }else{
                    
                   
                   apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*CNPJ Checker* - _Consulta completa de CNPJ, obtém todos os dados da empresa e nome do(s) proprietário(s) e sócio(s).

Formato:_
27865757000102
_ou_
27.865.757/0001-02

`#cnpj 27865757000102`", "reply_to_message_id" => $message_id,
'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));
                    
               }   
           }
        }


$verifica = substr(strtoupper($text), 0,5) == '#NOME';

if($verifica && $type == 'private') {
                
    date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);

    $array_usuarios = file("botcon/usuarios.txt");
    $total_usuarios_registrados = count($array_usuarios);

    $continuar = false;
    for($i=0;$i<count($array_usuarios);$i++){
        $explode = explode("|" , $array_usuarios[$i]);
        if($user_id == $explode[0]){
            $vencimento = $explode[1];
            $continuar = true;
        }
    }

    $timestamp_dt_expira = strtotime($vencimento);
				
    if(!$continuar || $timestamp_dt_atual > $timestamp_dt_expira){
         $verifica = "";
    }

}else if($verifica && $type != 'private') {
	
	date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);
			
    $array_grupos = file("botcon/grupos.txt");
    $total_grupos_registrados = count($array_grupos);

    $continuarGrupo = false;
    for($i=0;$i<count($array_grupos);$i++){
        $grupo_vip = explode("|" , $array_grupos[$i]);
        if($chat_id == "-$grupo_vip[0]"){
            $vencimento2 = $grupo_vip[1];
            $continuarGrupo = true;
         }
     }
            
     $timestamp_dt_expira2 = strtotime($vencimento2);
                   
     if(!$continuarGrupo || $timestamp_dt_atual > $timestamp_dt_expira2){                                                                                                                   
         apiRequest('leaveChat', array('chat_id' => $chat_id));                                                                                         
     }
 
}

        if($verifica){
            $login = substr($text, 6);
            if($login){            
               $comando = $login;

               include("botcon/nome.php");

            }else{
                
                if($type == 'private') {
                                                 
                    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*NOME Checker* - _Consulta simples de nome, obtém o número do CPF do portador.

Formato:_
LUCIANO SILVA

`#nome LUCIANO SILVA`",
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                              
                                                      )
                                                          
                                            )
                                    )));

                }else{
                    
                    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*NOME Checker* - _Consulta simples de nome, obtém o número do CPF do portador.

Formato:_
LUCIANO SILVA

`#nome LUCIANO SILVA`", "reply_to_message_id" => $message_id,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                              
                                                      )
                                                          
                                            )
                                    )));
                                  
                }
            }
        }


$verifica = substr(strtoupper($text), 0,7) == '#PLACA1';

if($verifica && $type == 'private') {
                
    date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);

    $array_usuarios = file("botcon/usuarios.txt");
    $total_usuarios_registrados = count($array_usuarios);

    $continuar = false;
    for($i=0;$i<count($array_usuarios);$i++){
        $explode = explode("|" , $array_usuarios[$i]);
        if($user_id == $explode[0]){
            $vencimento = $explode[1];
            $continuar = true;
        }
    }

    $timestamp_dt_expira = strtotime($vencimento);
				
    if(!$continuar || $timestamp_dt_atual > $timestamp_dt_expira){
         $verifica = "";
    }

}else if($verifica && $type != 'private') {
	
	date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);
			
    $array_grupos = file("botcon/grupos.txt");
    $total_grupos_registrados = count($array_grupos);

    $continuarGrupo = false;
    for($i=0;$i<count($array_grupos);$i++){
        $grupo_vip = explode("|" , $array_grupos[$i]);
        if($chat_id == "-$grupo_vip[0]"){
            $vencimento2 = $grupo_vip[1];
            $continuarGrupo = true;
         }
     }
            
     $timestamp_dt_expira2 = strtotime($vencimento2);
                   
     if(!$continuarGrupo || $timestamp_dt_atual > $timestamp_dt_expira2){                                                                                                                   
         apiRequest('leaveChat', array('chat_id' => $chat_id));                                                                                         
     }
 
}

        if($verifica){
            $login = substr($text, 8);
            if($login){
               $split = explode(" ", $login);               
               $comando = $split[0];

               include("botcon/placa.php");

            }else{
                
                if($type == 'private') {
                                                 
                     apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*PLACA Checker* - _Consulta simples de Placa, obtém informações sobre o veículo.

Formato:_
OGT0458

`#placa1 OGT0458`",
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                              
                                                      )
                                                          
                                            )
                                    )));

                }else{
                    
                    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*PLACA Checker* - _Consulta simples de Placa, obtém informações sobre o veículo.

Formato:_
OGT0458

`#placa1 OGT0458`", "reply_to_message_id" => $message_id,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                              
                                                      )
                                                          
                                            )
                                    )));
                
                }
            }
        }


$verifica = substr(strtoupper($text), 0,7) == '#PLACA2';

if($verifica && $type == 'private') {
                
    date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);

    $array_usuarios = file("botcon/usuarios.txt");
    $total_usuarios_registrados = count($array_usuarios);

    $continuar = false;
    for($i=0;$i<count($array_usuarios);$i++){
        $explode = explode("|" , $array_usuarios[$i]);
        if($user_id == $explode[0]){
            $vencimento = $explode[1];
            $continuar = true;
        }
    }

    $timestamp_dt_expira = strtotime($vencimento);
				
    if(!$continuar || $timestamp_dt_atual > $timestamp_dt_expira){
         $verifica = "";
    }

}else if($verifica && $type != 'private') {
	
	date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);
			
    $array_grupos = file("botcon/grupos.txt");
    $total_grupos_registrados = count($array_grupos);

    $continuarGrupo = false;
    for($i=0;$i<count($array_grupos);$i++){
        $grupo_vip = explode("|" , $array_grupos[$i]);
        if($chat_id == "-$grupo_vip[0]"){
            $vencimento2 = $grupo_vip[1];
            $continuarGrupo = true;
         }
     }
            
     $timestamp_dt_expira2 = strtotime($vencimento2);
                   
     if(!$continuarGrupo || $timestamp_dt_atual > $timestamp_dt_expira2){                                                                                                                   
         apiRequest('leaveChat', array('chat_id' => $chat_id));                                                                                         
     }
 
}

        if($verifica){
            $login = substr($text, 8);
            if($login){
               $split = explode(" ", $login);               
               $comando = $split[0];

               include("botcon/placa2.php");

            }else{
                
                if($type == 'private') {
                                                 
                     apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*PLACA Checker* - _Consulta completa de Placa, obtém informações sobre o veículo e sobre o proprietario.

Formato:_
OGT0458

`#placa2 OGT0458`",
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                              
                                                      )
                                                          
                                            )
                                    )));

                }else{
                    
                    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*PLACA Checker* - _Consulta completa de Placa, obtém informações sobre o veículo e sobre o proprietario.

Formato:_
OGT0458

`#placa2 OGT0458`", "reply_to_message_id" => $message_id,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                              
                                                      )
                                                          
                                            )
                                    )));
                
                }
            }
        }


$verifica = substr(strtoupper($text), 0,4) == '#TEL';

if($verifica && $type == 'private') {
                
    date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);

    $array_usuarios = file("botcon/usuarios.txt");
    $total_usuarios_registrados = count($array_usuarios);

    $continuar = false;
    for($i=0;$i<count($array_usuarios);$i++){
        $explode = explode("|" , $array_usuarios[$i]);
        if($user_id == $explode[0]){
            $vencimento = $explode[1];
            $continuar = true;
        }
    }

    $timestamp_dt_expira = strtotime($vencimento);
				
    if(!$continuar || $timestamp_dt_atual > $timestamp_dt_expira){
         $verifica = "";
    }

}else if($verifica && $type != 'private') {
	
	date_default_timezone_set('America/Recife');
    $dt_atual = date("Y/m/d H:i:s");
    $timestamp_dt_atual = strtotime($dt_atual);
			
    $array_grupos = file("botcon/grupos.txt");
    $total_grupos_registrados = count($array_grupos);

    $continuarGrupo = false;
    for($i=0;$i<count($array_grupos);$i++){
        $grupo_vip = explode("|" , $array_grupos[$i]);
        if($chat_id == "-$grupo_vip[0]"){
            $vencimento2 = $grupo_vip[1];
            $continuarGrupo = true;
         }
     }
            
     $timestamp_dt_expira2 = strtotime($vencimento2);
                   
     if(!$continuarGrupo || $timestamp_dt_atual > $timestamp_dt_expira2){                                                                                                                   
         apiRequest('leaveChat', array('chat_id' => $chat_id));                                                                                         
     }
 
}

        if($verifica){
            $login = substr($text, 5);
            if($login){
               $split = explode(" ", $login);               
               $comando = $split[0];

               include("botcon/telefone.php");

            }else{
                
                if($type == 'private') {
                                                 
                    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*TELEFONE Checker* - _Consulta completa de Número de Telefone, obtém todos os dados do dono do Telefone.

Formato:_
51995379721

`#tel 51995379721`",
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                              
                                                      )
                                                          
                                            )
                                    )));

                }else{

                   apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*TELEFONE Checker* - _Consulta completa de Número de Telefone, obtém todos os dados do dono do Telefone.

Formato:_
51995379721

`#tel 51995379721`", "reply_to_message_id" => $message_id,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                             
                                                      )
                                                          
                                            )
                                    )));

               }
           }
        }

       
       if(strpos($text, "#planos") !== false ){
            
           include("botcon/planos2.php");

       }else if(strpos($text, "#musica") === 0) {                         
          
           $imagem = explode(" ", $text); 
           $comando = explode("https://youtu.be/", $text);      
           if($comando) {     
                include("ferramentas/youtube.php");
            }       

       }


$verifica = substr(strtoupper($text), 0,8) == '#CREDITO';

        if($verifica){
            $login = substr($text, 9);
            if($login){
               $split = explode(" ", $login);               
               $comando = $split[0];
               $id_creditos = explode("|", $comando);
               $id = $id_creditos[0];
               $creditos = $id_creditos[1];
              
               if ($user_id == $adm || $user_id == $adm2) {
                   
                   $array_creditos = file("botcon/creditos.txt");
                   $total_creditos_registrados = count($array_creditos);
                  
                   $continuar = false;
                   for($i=0;$i<count($array_creditos);$i++){
                       $explode = explode("|" , $array_creditos[$i]);
                       if($id == $explode[0]){         
                           $creditos_list = $explode[1];
                           $continuar = true;
                        }
                    }

                    if($continuar){
                      $somaCreditos = $creditos_list + $creditos;
                        
                       $arquivo = file_get_contents('botcon/creditos.txt');
                       $linhas = explode("\n", $arquivo);
                       $palavra = $id;
                       foreach($linhas as $linha => $valor) {
                           $posicao = preg_match("/\b$palavra\b/i", $valor);                      
                           if($posicao) {
                               unset($linhas[$linha]);                                  
                           }
                       }
                       $arquivo = implode("\n", $linhas);
                       file_put_contents('botcon/creditos.txt', $arquivo);
                       
                       if($file = fopen("botcon/creditos.txt","a+")) {
                           fputs($file, $id."|".$somaCreditos."\n");   
                       
                           apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "✅ *Créditos adicionados*

━━━━━━━━━━━━━━━━━
ID de Usuário  |  Créditos Atuais
━━━━━━━━━━━━━━━━━
ID:".$id." | ".$somaCreditos,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));
      
                       }

                   } else {
	                   if($file = fopen("botcon/creditos.txt","a+")) {
                           fputs($file, $id."|".$creditos."\n");                     
                           
                           apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "✅ *Créditos adicionados*

━━━━━━━━━━━━━━━━━
ID de Usuário  |  Créditos Adicionados
━━━━━━━━━━━━━━━━━
ID:".$id." | ".$creditos,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));
 
                      }
                  }
               }
           }
        }


$verifica = substr(strtoupper($text), 0,4) == '#ADC';

        if($verifica){
            $login = substr($text, 5);
            if($login){
               $split = explode(" ", $login);               
               $comando = $split[0];
               $hora_marcada = $split[1];

               if($hora_marcada == ""){

                   $hora_marcada = $hora;

               }

               $id_data = explode("|", $comando);
          
               $dt = explode("/", $id_data[1]);
               $dia = $dt[0];
               $mes = $dt[1];
               $ano = $dt[2];

               if ($user_id == $adm || $user_id == $adm2) {
                   
                   $array_usuarios = file("botcon/usuarios.txt");
                   $total_usuarios_registrados = count($array_usuarios);
                   $adc_id = explode("|" , $comando);

                   $continuar = false;
                   for($i=0;$i<count($array_usuarios);$i++){
                       $explode = explode("|" , $array_usuarios[$i]);
                       if($adc_id[0] == $explode[0]){         
                           $dt_lista = $explode[1];
                           $continuar = true;
                        }
                    }

                    $dt_hora = explode(" ", $dt_lista);

                    $converte_dt = explode("/", $dt_hora[0]);
                    $c_ano = $converte_dt[0];
                    $c_mes = $converte_dt[1];
                    $c_dia = $converte_dt[2];

                    if($continuar){
                       
                       apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "🚫 *O usuário já está na lista VIP*

━━━━━━━━━━━━━━━━━
ID de Usuário  |  Data de Vencimento
━━━━━━━━━━━━━━━━━
ID:".$adc_id[0]."|".$c_dia."/".$c_mes."/".$c_ano." ".$dt_hora[1],
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

                   } else {
	                   if($file = fopen("botcon/usuarios.txt","a+")) {
                           fputs($file, $id_data[0]."|".$ano."/".$mes."/".$dia." ".$hora_marcada."\n");                     
                           
                           apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "✅ *Usuário incluido na lista VIP*

━━━━━━━━━━━━━━━━━
ID de Usuário  |  Data de Vencimento
━━━━━━━━━━━━━━━━━
ID:".$comando." ".$hora_marcada,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));
 
                      }
                  }
               }
           }
        }


$verifica = substr(strtoupper($text), 0,3) == '#RM';

        if($verifica){
            $login = substr($text, 4);
            if($login){
               $split = explode(" ", $login);               
               $comando = $split[0];

               $id_creditos = explode("|", $comando);

               $id = $id_creditos[0];
               $creditos = $id_creditos[1];

               if ($user_id == $adm || $user_id == $adm2) {

                   $array_usuarios = file("botcon/usuarios.txt");
                   $total_usuarios_registrados = count($array_usuarios);
                   
                   $continuar = false;
                   for($i=0;$i<count($array_usuarios);$i++){
                       $explode = explode("|" , $array_usuarios[$i]);
                       if($id == $explode[0]){         
                           $continuar = true;
                        }
                    }

                   if(!$continuar){
                       
                       apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "🚫 *O usuário não está na lista VIP*

━━━━━━━━━━━━━━━━━
ID de Usuário  |  Data da Pesquisa
━━━━━━━━━━━━━━━━━
ID:".$id."|".$dataCerta." ".$hora,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

                   } else {

                  $arquivo = file_get_contents('botcon/usuarios.txt');
                  $linhas = explode("\n", $arquivo);
                  $palavra = $id;
                  foreach($linhas as $linha => $valor) {
                      $posicao = preg_match("/\b$palavra\b/i", $valor);                      
                      if($posicao) {
                          unset($linhas[$linha]);
                          
                          apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "✅ *Usuário excluido da lista VIP*

━━━━━━━━━━━━━━━━━
ID de Usuário  |  Data da Exclusão
━━━━━━━━━━━━━━━━━
ID:".$id."|".$dataCerta." ".$hora,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));
                  
                      }
                  }
                  $arquivo = implode("\n", $linhas);
                  file_put_contents('botcon/usuarios.txt', $arquivo);                    
                
                  }
               }
           }
        }



              if(strpos($text, "#saldo") !== false ){
            
                   $array_creditos = file("botcon/creditos.txt");
                   $total_creditos_registrados = count($array_creditos);
                  
                   $continuar = false;
                   for($i=0;$i<count($array_creditos);$i++){
                       $explode = explode("|" , $array_creditos[$i]);
                       if($user_id == $explode[0]){         
                           $creditos_list = $explode[1];
                           $continuar = true;
                        }
                    }
                                        
                    if($continuar && $creditos_list > 0){
                        if($type == 'private') {
                           
                           apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "🏦 *CRÉDITOS SCORE*

*━━━━━━━━━━━━━━━━━*
*🧑🏻 Nome:* $first_name
*━━━━━━━━━━━━━━━━━*
*🆔:* `$user_id`
*━━━━━━━━━━━━━━━━━*
*✅ Seu crédito:* ".$creditos_list,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

                        }else{
                            
                            apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "🏦 *CRÉDITOS SCORE*

*━━━━━━━━━━━━━━━━━*
*🧑🏻 Nome:* $first_name
*━━━━━━━━━━━━━━━━━*
*🆔:* `$user_id`
*━━━━━━━━━━━━━━━━━*
*✅ Seu crédito:* ".$creditos_list, "reply_to_message_id" => $message_id,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

                        }
                   }else{
                       $creditos_list = 0;
                       if($type == 'private') {
                           
                           apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "🏦 *CRÉDITOS SCORE*

*━━━━━━━━━━━━━━━━━*
*🧑🏻 Nome:* $first_name
*━━━━━━━━━━━━━━━━━*
*🆔:* `$user_id`
*━━━━━━━━━━━━━━━━━*
*🚫 Seu crédito:* ".$creditos_list,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

                        }else{
                            
                            apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "🏦 *CRÉDITOS SCORE*

*━━━━━━━━━━━━━━━━━*
*🧑🏻 Nome:* $first_name
*━━━━━━━━━━━━━━━━━*
*🆔:* `$user_id`
*━━━━━━━━━━━━━━━━━*
*🚫 Seu crédito:* ".$creditos_list, "reply_to_message_id" => $message_id,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

                       }
                  }
             }
       

       if(strpos($text, "#lista") === 0) {
                        
            if ($user_id == $adm) {
            
                $array_usuarios = file("botcon/usuarios.txt");
                $total_usuarios_registrados = count($array_usuarios);
                
                $lista = file_get_contents('botcon/usuarios.txt');
                                                               
                apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "📋 *Lista de Usuários VIP*
━━━━━━━━━━━━━━━━━
ID de Usuário  |  Data de Vencimento
━━━━━━━━━━━━━━━━━
$lista
━━━━━━━━━━━━━━━━━
Total de Usuários: ".$total_usuarios_registrados,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

            }
        }


      if(strpos($text, "#vip") !== false || strpos($text, "#Vip") !== false || strpos($text, "#VIP") !== false){
            
                   $array_usuarios = file("botcon/usuarios.txt");
                   $total_usuarios_registrados = count($array_usuarios);
                  
                   $continuar = false;
                   for($i=0;$i<count($array_usuarios);$i++){
                       $explode = explode("|" , $array_usuarios[$i]);
                       if($user_id == $explode[0]){         
                           $dt_lista = $explode[1];
                           $continuar = true;
                        }
                    }
                                        
                    $dt_hora = explode(" ", $dt_lista);

                    $converte_dt = explode("/", $dt_hora[0]);
                    $c_ano = $converte_dt[0];
                    $c_mes = $converte_dt[1];
                    $c_dia = $converte_dt[2];

                                                                                                                                                                                                                                                                                  
                    if($continuar){
                        if($type == 'private') {
                           
                           apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "✅ *Informações de Planos*

*━━━━━━━━━━━━━━━━━*
*🧑🏻 Nome:* $first_name
*━━━━━━━━━━━━━━━━━*
*🆔:* `$user_id`
*━━━━━━━━━━━━━━━━━*
*🗓 Vencimento:* $c_dia/$c_mes/$c_ano - $dt_hora[1]",
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

                        }else{
                            
                            apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "✅ *Informações de Planos*

*━━━━━━━━━━━━━━━━━*
*🧑🏻 Nome:* $first_name
*━━━━━━━━━━━━━━━━━*
*🆔:* `$user_id`
*━━━━━━━━━━━━━━━━━*
*🗓 Vencimento:* $c_dia/$c_mes/$c_ano - $dt_hora[1]", "reply_to_message_id" => $message_id,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

                        }
                   }else{                  
                       if($type == 'private') {
                           
                           apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "🚫 *Você não tem um Plano*

*━━━━━━━━━━━━━━━━━*
*🧑🏻 Nome:* $first_name
*━━━━━━━━━━━━━━━━━*
*🆔:* `$user_id`
*━━━━━━━━━━━━━━━━━*
*🚫 Você não tem um Plano*",
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>'apagar')//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

                        }else{
                            
                            apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "🚫 *Você não tem um Plano*

*━━━━━━━━━━━━━━━━━*
*🧑🏻 Nome:* $first_name
*━━━━━━━━━━━━━━━━━*
*🆔:* `$user_id`
*━━━━━━━━━━━━━━━━━*
*🚫 Você não tem um Plano*", "reply_to_message_id" => $message_id,
     'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));

                       }
                  }
             }

        
        if(strpos($text, "#menu") === 0) {          
           if($type == 'private') {
                
               date_default_timezone_set('America/Recife');
               $dt_atual = date("Y/m/d H:i:s");
               $timestamp_dt_atual = strtotime($dt_atual);

               $array_usuarios = file("botcon/usuarios.txt");
               $total_usuarios_registrados = count($array_usuarios);

               $continuar = false;
               for($i=0;$i<count($array_usuarios);$i++){
                   $explode = explode("|" , $array_usuarios[$i]);
                   if($user_id == $explode[0]){
                       $vencimento = $explode[1];
                       $continuar = true;
                   }
               }

              $timestamp_dt_expira = strtotime($vencimento);
				
			  if($continuar && $timestamp_dt_atual < $timestamp_dt_expira){
            
                  apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => '*⚙️ 𝗠𝗘𝗡𝗨 𝗗𝗘 𝗖𝗢𝗠𝗔𝗡𝗗𝗢𝗦 ⚙️*',   
		          'reply_markup' => array('inline_keyboard' => array(                                                                                                            
                                                     //linha 1
                                                     array(                                                                                                               
                                                         array('text'=>'🌐 CONSULTAS VIP 🌐',"callback_data"=>'consultas')
                                                      ),
                                                     //linha 2
                                                     array(
                                                         array('text'=>'🎵 Baixar músicas do YouTube 🎵',"callback_data"=>'youtube')                        
                                                     )
                                            )
                                    )));

               }
                
           }else{
               
               date_default_timezone_set('America/Recife');
               $dt_atual = date("Y/m/d H:i:s");
               $timestamp_dt_atual = strtotime($dt_atual);
			
               $array_grupos = file("botcon/grupos.txt");
               $total_grupos_registrados = count($array_grupos);

               $continuarGrupo = false;
               for($i=0;$i<count($array_grupos);$i++){
                   $grupo_vip = explode("|" , $array_grupos[$i]);
                   if($chat_id == "-$grupo_vip[0]"){
                       $vencimento2 = $grupo_vip[1];
                       $continuarGrupo = true;
                   }
               }
            
              $timestamp_dt_expira2 = strtotime($vencimento2);
                   
              if(!$continuarGrupo || $timestamp_dt_atual > $timestamp_dt_expira2){                                                                                                                   
                  apiRequest('leaveChat', array('chat_id' => $chat_id));                                                                                         
              }
             
               apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => '*⚙️ 𝗠𝗘𝗡𝗨 𝗗𝗘 𝗖𝗢𝗠𝗔𝗡𝗗𝗢𝗦 ⚙️*', 'reply_to_message_id' => $message_id,
		       'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                                                                                   
                                                     //linha 1
                                                     array(                                                                                                               
                                                         array('text'=>'🌐 CONSULTAS VIP 🌐',"callback_data"=>'consultas')
                                                      ),
                                                     //linha 2
                                                     array(
                                                         array('text'=>'🎵 Baixar músicas do YouTube 🎵',"callback_data"=>'youtube')                        
                                                     )
                                            )
                                    )));
            
                      
             }
         }


       switch ($text) {    
       case '#id': 

            if($type == 'private') {

                if ($username != "") {
                    
                    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*📁 INFORMAÇÕES DO USUÁRIO:

🆔:* `".$user_id."`
*🧑🏻 Nome:* $first_name $last_name
*🌐 Username: *[@$username](tg://user?id=$user_id)", "reply_to_message_id" => $message_id));          
                } else {
                	
                    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*📁 INFORMAÇÕES DO USUÁRIO:

🆔:* `".$user_id."`
*🧑🏻 Nome:* $first_name $last_name", "reply_to_message_id" => $message_id));          
                }

           } else {

                if ($username != "") {
                    
                    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*📁 INFORMAÇÕES DO GRUPO:

Chat ID:* `".$chat_id."`
*Titulo:* $titulo

*📁 INFORMAÇÕES DO USUÁRIO:*

*🆔:* `".$user_id."`
*🧑🏻 Nome:* $first_name $last_name
*🌐 Username: *[@$username](tg://user?id=$user_id)", "reply_to_message_id" => $message_id,
'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));    
 
               } else {
                	
                    apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => "*📁 INFORMAÇÕES DO GRUPO:

Chat ID:* `".$chat_id."`
*Titulo:* $titulo

*📁 INFORMAÇÕES DO USUÁRIO:*

*🆔:* `".$user_id."`
*🧑🏻 Nome:* $first_name $last_name", "reply_to_message_id" => $message_id,
'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                    
                                                      //linha 1
                                                     array(
                                                         array('text'=>'🗑  Apagar  🗑',"callback_data"=>serialize(['id'=>$user_id, 'data'=>'apagar']))//botão com callback                                                   
                                                      )
                                                          
                                            )
                                    )));     

                }

           }

           break;
     
       }

                    
        switch ($text) {    
        case '/start':    
             
		   if($type == 'private') {
			
		       date_default_timezone_set('America/Recife');
               $dt_atual = date("Y/m/d H:i:s");
               $timestamp_dt_atual = strtotime($dt_atual);

               $array_usuarios = file("botcon/usuarios.txt");
               $total_usuarios_registrados = count($array_usuarios);

               $continuar = false;
               for($i=0;$i<count($array_usuarios);$i++){
                   $explode = explode("|" , $array_usuarios[$i]);
                   if($user_id == $explode[0]){
                       $vencimento = $explode[1];
                       $continuar = true;
                   }
               }

              $timestamp_dt_expira = strtotime($vencimento);
				
			  if($continuar && $timestamp_dt_atual < $timestamp_dt_expira){
				
                  apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => '*Olá, *'. $message['from']['first_name'].'! 
*Meu nome é @BIGCONSULTASBOT. Adicione-me em um grupo e me coloque como Admin para utilizar todos os meus recursos!

Conheça abaixo, todos os meus comandos:*', 
		         'reply_markup' => array('inline_keyboard' => array(
                                                     //linha 1
                                                     array(                                                                                                               
                                                         array('text'=>'🌐 CONSULTAS VIP 🌐',"callback_data"=>'consultas')
                                                      ),
                                                     //linha 2
                                                     array(
                                                         array('text'=>'🎵 Baixar músicas do YouTube 🎵',"callback_data"=>'youtube')                        
                                                     )
                                            )
                                    )));

              }
                               
		  }else{
			
			   date_default_timezone_set('America/Recife');
               $dt_atual = date("Y/m/d H:i:s");
               $timestamp_dt_atual = strtotime($dt_atual);
			
               $array_grupos = file("botcon/grupos.txt");
               $total_grupos_registrados = count($array_grupos);

               $continuarGrupo = false;
               for($i=0;$i<count($array_grupos);$i++){
                   $grupo_vip = explode("|" , $array_grupos[$i]);
                   if($chat_id == "-$grupo_vip[0]"){
                       $vencimento2 = $grupo_vip[1];
                       $continuarGrupo = true;
                   }
               }
            
              $timestamp_dt_expira2 = strtotime($vencimento2);
                   
              if(!$continuarGrupo || $timestamp_dt_atual > $timestamp_dt_expira2){                                                                                                                   
                  apiRequest('leaveChat', array('chat_id' => $chat_id));                                                                                         
              }
				
              apiRequest("sendMessage", array('chat_id' => $chat_id, "parse_mode" => "Markdown", "text" => '*Olá, *'. $message['from']['first_name'].'! *Eu já fui adicionado nesse grupo!

Conheça abaixo, todos os meus comandos:*', 'reply_to_message_id' => $message_id,
		'reply_markup' => array('inline_keyboard' => array(                                                     
                                                     //linha 1
                                                     array(                                                                                                               
                                                         array('text'=>'🌐 CONSULTAS VIP 🌐',"callback_data"=>'consultas')
                                                      ),
                                                     //linha 2
                                                     array(
                                                         array('text'=>'🎵 Baixar músicas do YouTube 🎵',"callback_data"=>'youtube')                        
                                                     )
                                            )
                                    )));
                                    
		   }
                         
       break;
     
       }    
	}
} 



define('WEBHOOK_URL', 'https://vander-checkers-2020.000webhostapp.com/BIGCONSULTASBOT/bot.php');
if (php_sapi_name() == 'cli') {
  // if run from console, set or delete webhook
  apiRequest('setWebhook', array('url' => isset($argv[1]) && $argv[1] == 'delete' ? '' : WEBHOOK_URL));
  exit;
}
$content = file_get_contents("php://input");
$update = json_decode($content, true);
if (!$update) {
  exit;
} else if (isset($update["message"])) {
  processMessage($update["message"]);
} else if (isset($update["callback_query"])) {
  processaCallbackQuery($update["callback_query"]);
}


?>